//
//  calculatorDomainModel.swift
//  my-calculator
//
//  Created by Jay on 2021/4/23.
//

import Foundation

class CalculatorDomainModel {
    var input:String
    var operation:String
    var log:[String]
    var infix_expression:[String]
    var postfix_expression:[String] {
        get {
            var op:[String] = ["#"]
            var postfix:[String] = []
            
            if Double(infix_expression.first!) == nil {
                postfix += [post_result]
            }
            for token in infix_expression {
                if nil != Double(token) {
                    postfix += [token]
                } else {
                    if precedence(of: token) > precedence(of: op.last!) {
                        op.append(token)
                    } else {
                        while precedence(of: op.last!) != -1,
                              precedence(of: token) <= precedence(of: op.last!) {
                            postfix += [op.popLast()!]
                        }
                        op.append(token);
                    }
                }
            }
            while op.last! != "#" {
                postfix += [op.popLast()!]
            }
            return postfix;
        }
    }
    
    var expression:String {
        get {
            var str = ""
            if infix_expression.count == 0 {
                return post_result
            }
            if Double(infix_expression.first!) == nil {
                str = post_result
            }
            for term in infix_expression {
                if Double(term) == nil {
                    str += term
                } else {
                    if is_integer(Double(term)!) {
                        str += String(format: "%.0f", Double(term)!)
                    } else {
                        str += term
                    }
                }
            }
            return str
        }
    }
    
    var result:String {
        get {
            var result_stack:[Double] = []
            for token in postfix_expression {
                if let num = Double(token) {
                    result_stack += [num]
                } else {
                    let b = result_stack.popLast() ?? 0
                    let a = result_stack.popLast() ?? 0
                    switch token {
                    case "+":
                        result_stack += [a+b]
                    case "−":
                        result_stack += [a-b]
                    case "×":
                        result_stack += [a*b]
                    case "÷":
                        if b == 0 {
                            result_stack += [0]
                        } else {
                            result_stack += [a/b]
                        }
                    default:
                        break
                    }
                }
            }
            if result_stack.count == 0 {
                return "0"
            }
            if result_stack[0] == floor(result_stack[0]) {
                return "\(Int(result_stack[0]))"
            } else {
                return "\(result_stack[0])"
            }
        }
    }
    
    let post_result:String

    init(postresult:String) {
        input = ""
        operation = ""
        log = []
        infix_expression = []
        post_result = postresult
        
    }
    
    func precedence(of op:String) -> Int {
        switch op {
        case "+", "-":
            return 0
        case "×", "÷":
            return 1
        default:
            return -1
        }
    }
    
    func update_exp() {
        if input != "" {
            if (operation != ""){
                infix_expression += [operation]
            }
            infix_expression += [String(Double(input)!)]
        } else {
            if (operation != ""){
                infix_expression += [operation]
            }
            infix_expression += [String(Double(post_result)!)]
        }
    }
    
    func is_integer(_ num:Double) -> Bool {
        return floor(num) == num
    }
    
    func is_input_integer() -> Bool {
        return is_integer(Double(input)!)
    }
    
    func negative_input() {
        if input == "" {
            input = String(0 - Double(post_result)!)
        } else {
            input = String(0 - Double(input)!)
        }
    }
    
    func percent_input() {
        input = "\(Double(input == "" ? post_result : input)! * 0.1)"
    }
}
