//
//  ViewController.swift
//  my-calculator
//
//  Created by Jay on 2021/3/8.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var log: UILabel!
    
    @IBOutlet weak var result: UILabel!
        
    var model = CalculatorDomainModel(postresult: "0")
    
    var dot_btn_enable = false
    var dot_btn_active = false
    var equal_btn_active = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func num_btn(_ sender: UIButton) {
        if equal_btn_active {
            model = CalculatorDomainModel(postresult: model.result)
            equal_btn_active = false
        }
        if dot_btn_active {
            model.input += "."
            dot_btn_enable = false
            dot_btn_active = false
        } else {
            dot_btn_enable = true
        }
        model.input += String(sender.tag)
        result.text = model.input
    }

    @IBAction func dot_btn(_ sender: UIButton) {
        if dot_btn_enable {
            dot_btn_active = true
            result.text = model.input + "."
        }
    }
    
    @IBAction func sign_btn(_ sender: UIButton) {
        if model.input != "" {
            model.update_exp()
        }
        switch sender.tag {
        case 1:
            model.operation = "+"
        case 2:
            model.operation = "−"
        case 3:
            model.operation = "×"
        case 4:
            model.operation = "÷"
        default:
            break
        }
        log.text = model.expression + model.operation
        result.text = ""
        
        model.input = ""
        dot_btn_enable = false
        dot_btn_active = false
    }

    @IBAction func equal(_ sender: UIButton) {
        model.update_exp()
        log.text = model.expression + "="
        result.text = model.result
        
        dot_btn_enable = false
        dot_btn_active = false
        equal_btn_active = true
    }
    
    @IBAction func all_clear(_ sender: UIButton) {
        log.text = "0"
        result.text = "0"
    
        model = CalculatorDomainModel(postresult: "0")
        dot_btn_enable = false
        dot_btn_active = false
        equal_btn_active = false
    }
    
    @IBAction func negative(_ sender: UIButton) {
        if equal_btn_active {
            model.input = model.result
            equal_btn_active = false
        }
        log.text = "±(\(model.input))"
        model.negative_input()
        result.text = model.input
    }
    
    @IBAction func percent(_ sender: UIButton) {
        if equal_btn_active {
            model.input = model.result
            equal_btn_active = false
        }
        log.text = "\(model.input)%"
        model.percent_input()
        dot_btn_enable = !model.is_input_integer()
        result.text = model.input
    }
}
