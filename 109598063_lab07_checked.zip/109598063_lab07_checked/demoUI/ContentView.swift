//
//  ContentView.swift
//  demoUI
//
//  Created by Jay on 2021/4/26.
//

import SwiftUI

struct ContentView: View {
    @State var showSecondPage = false
    @State var subtitle = ""
    
    let menuItems = ["貓貓蟲-咖波", "狗狗", "拉拉", "奶泡貓"]
    
    var body: some View {
        
        VStack {
        
            Text("貓貓蟲咖波")
                .padding()
                .font(.largeTitle)
            Image("capoo_cover")
       
            ForEach(0 ..< menuItems.count) { index in
                Button(action: {
                    showSecondPage = true
                    subtitle = menuItems[index]
                }, label: {
                    Text(menuItems[index]).font(.title)
                }).sheet(isPresented: $showSecondPage, content: {
                    carView(showSecondPage: $showSecondPage, title: $subtitle)
                })
            }

        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//func testlabda(_ fn:()->Void) {
//    fn()
//}
