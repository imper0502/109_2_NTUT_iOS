//
//  carView.swift
//  demoUI
//
//  Created by Jay on 2021/5/3.
//

import SwiftUI

struct carView: View {
    @Binding var showSecondPage:Bool
    @Binding var title:String

    let stringArr = [
        "雄性，本作品主角，生日是2014年5月19日(作者設定)，外型頭部像貓身體像蟲的小怪物，毛皮是藍色，背上有三條紋路，平時有六隻腳(有時會依比例拉長而增多)",
        "卵生，但是父母不詳",
        "極度喜歡吃肉，身邊活著的任何小動物都會被抓來吃，但絕對不吃蔬菜(但甜甜的水果可以)，一吃就會嘔吐(漫畫表現為吐出彩虹)，似乎對巧克力免疫(貓不能吃巧克力，但咖波卻不受影響。)",
        "被殺蟲劑噴到也會昏迷。",
        "原本出生時在野外，在一次寒流快被凍死的危機下被女主人拉拉撿回家收養當寵物",
        "有時不乖或是做壞事蠢事會被女主人拉拉揍"
    ]
    var body: some View {
        
        NavigationView {
            VStack{
                ZStack(){
                    Color.yellow
                    
                    VStack {
                        ForEach(0 ..< stringArr.count) { i in
                            Text(stringArr[i])
                        }
                    }
                }.overlay(
                    Button(action: {
                        showSecondPage = false
                    }, label: {
                        Image(systemName: "xmark.circle.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .padding(20)
                    }), alignment: .topTrailing)
                .navigationTitle(title)

            }
            
        }
    }
}

struct carView_Previews: PreviewProvider {
    static var previews: some View {
        carView(showSecondPage: .constant(false), title: .constant("capoo"))
    }
}
