//
//  demoUIApp.swift
//  demoUI
//
//  Created by Jay on 2021/4/26.
//

import SwiftUI

@main
struct demoUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
